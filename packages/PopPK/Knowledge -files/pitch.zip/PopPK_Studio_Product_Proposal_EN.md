# PopPK Studio — Product Proposal

**Browser-native population PK/PD modeling for Datagrok**

---

## 1. Problem and Rationale

### The pain

Population pharmacokinetic modeling (PopPK) is a regulatory requirement for virtually every drug approval. The FDA's Division of Pharmacometrics reviews PopPK analyses in over 85% of new drug applications, and ICH M15 (effective July 2026) will make model-informed drug development a global regulatory expectation. Yet the tools pharmacometricians use daily are fragmented, archaic, and painful.

A single PopPK analysis requires **4–6 disconnected tools**: NONMEM (Fortran-based, no GUI, command-line only) for estimation, R for diagnostics, PsN for automation, Excel for data assembly, Word for reporting, and email for collaboration. The pharmacometrician spends more time fighting tooling than doing science. A typical analysis cycle takes **6–8 weeks** — not because the math is slow, but because the workflow is broken.

The four personas who suffer most in pharma:

- **Pharmacometrician**: hours debugging Fortran-era syntax errors; no version control; "which control stream is final?"
- **Clinical pharmacologist**: every "what if I change the dose?" question takes days because they depend on the pharmacometrician to re-run code
- **Biostatistician**: two days per study just merging exposure metrics with efficacy datasets across incompatible tools
- **Program leadership**: static PowerPoint slides; cannot answer ad-hoc dose questions in governance meetings; every week of delayed dose selection costs $500K–$2M

### Why existing solutions fall short

| Competitor | Core weakness |
|-----------|--------------|
| **NONMEM** (ICON, ~85% FDA submissions) | No GUI, no visualization, Fortran syntax, fragmented ecosystem |
| **Monolix** (Simulations Plus) | No FOCE method, no browser-native, desktop-only |
| **Phoenix NLME** (Certara) | No SAEM, no Bayesian, Windows desktop |
| **nlmixr2** (open-source R) | No GUI, steep learning curve, R-only |
| **Pumas** (PumasAI, Julia) | Julia unfamiliar to most users, small community, opaque pricing |

**The critical gap: no browser-native pharmacometrics platform exists.** Every competitor is desktop-installed, code-first, or cloud-wrapped desktop. No tool offers a unified workflow from data to regulatory report in a zero-install browser environment.

---

## 2. Value to the Product

### Market opportunity

The pharmacometric modeling software market is valued at **$613–680 million (2024)**, growing at **10–13% CAGR** to $1.4–2.1 billion by 2033. The broader model-informed drug development market — including consulting, services, and infrastructure — is significantly larger.

### Retention and new customer acquisition

PopPK Studio creates a **high-switching-cost workflow anchor** within Datagrok. Once a pharma team builds their model library and analysis templates on the platform, migration cost is substantial. Key dynamics:

- **Land**: NCA and data exploration (leveraging existing Datagrok strengths) bring clinical pharmacologists into the platform
- **Expand**: PopPK modeling captures the pharmacometrics team — the most tool-loyal group in pharma
- **Lock-in**: Model libraries, analysis templates, and audit trails create institutional dependency
- **Upsell**: Server-side compute, collaboration features, and regulatory reporting modules

Target customers: the 1,500+ pharma organizations currently using Phoenix WinNonlin for NCA, where Datagrok can offer a superior browser-native NCA experience as the entry wedge, then expand to PopPK.

### Strategic alignment with Datagrok roadmap

PopPK Studio builds directly on four existing Datagrok capabilities:

- **Diff Studio** (ODE solver + code editor) → becomes the model specification engine
- **Compute-utils** (WebWorker fitting + Nelder-Mead) → becomes the estimation infrastructure
- **PipelineView / TreeWizard** → becomes the guided workflow for clinical pharmacologists
- **40+ database connectors + columnar engine** → becomes the data assembly layer

This is not a standalone product — it is the flagship demonstration of Datagrok's scientific computing platform applied to a high-value, regulation-driven domain. Success here validates the architecture for adjacent modules (PBPK, QSP, bioassay analysis).

---

## 3. Scope and Estimates

### MVP — Phase 1 (Months 1–4)

| Component | What it does |
|-----------|-------------|
| NMTRAN data parser | Import/validate standard pharmacometric datasets (ID, TIME, DV, AMT, EVID, CMT) |
| Analytical PK model library | 6 models: 1-compartment and 2-compartment with IV/oral, TRANS2/TRANS4 parameterizations |
| MAP/EBE estimation | Individual parameter estimation using Nelder-Mead + L-BFGS |
| Individual fit viewer | Observed vs. predicted concentration-time plots per subject |
| Basic simulation | Deterministic simulation from individual estimates |

**MVP delivers immediate value** for model-informed precision dosing (MIPD/TDM) — a growing clinical application where existing tools require local installation and technical expertise. A browser-based MAP estimator with a model library is immediately useful to hospital pharmacists and clinical pharmacologists.

### Full roadmap

| Phase | Timeline | Key deliverables |
|-------|----------|-----------------|
| Phase 1 | Months 1–4 | MVP: data parser, analytical models, MAP estimation, individual fits |
| Phase 2 | Months 4–8 | SAEM engine, population parameter estimation, core diagnostics (GOF, CWRES, shrinkage), Monte Carlo simulation |
| Phase 3 | Months 8–12 | FOCE-I, WASM CVODES, VPC, bootstrap, stepwise covariate modeling, NONMEM import, model DSL |
| Phase 4 | Months 12–18 | Automated reporting (Word/PDF), Bayesian (server-side), interactive dashboards, NONMEM export, FREM, NPDE |

### Estimated effort

- **Phase 1**: 2–3 developers, 4 months → **8–12 person-months**
- **Phase 2**: 3–4 developers, 4 months → **12–16 person-months**
- **Phase 3**: 3–4 developers, 4 months → **12–16 person-months**
- **Phase 4**: 3–4 developers, 6 months → **18–24 person-months**
- **Total through Phase 4**: **~50–68 person-months** over 18 months

---

## 4. Risks

### Technical risks

| Risk | Severity | Mitigation |
|------|----------|-----------|
| **Browser performance for NLME estimation** | High | Analytical PK models (Phase 1) avoid ODE overhead; WASM compilation of SUNDIALS CVODES (Phase 3) delivers near-native speed; server-side fallback for large datasets |
| **FOCE-I numerical accuracy** | High | Must match NONMEM OFV to 3+ significant figures; use nlmixr2's published validation datasets (theophylline, warfarin); forward sensitivity equations via CVODES for accurate gradients |
| **SAEM convergence** | Medium | Follow Monolix's proven two-phase implementation (exploratory + smoothing); simulated annealing for global exploration; multi-start capability |
| **WebAssembly SUNDIALS compilation** | Medium | SUNDIALS is pure C with minimal dependencies; Emscripten compilation well-documented; fallback to diff-grok (Rosenbrock) if WASM delayed |
| **Missing JS/TS libraries** | Low | Metropolis-Hastings sampler is algorithmically simple (custom); stdlib-js + ml-matrix cover linear algebra needs |

### Strategic risks

| Risk | Severity | Mitigation |
|------|----------|-----------|
| **Regulatory acceptance** | High | NONMEM interoperability (import/export) ensures any PopPK Studio result can be verified in NONMEM; FDA guidance is explicitly software-agnostic; nlmixr2 has demonstrated regulatory acceptance |
| **NONMEM inertia** | High | Do not attempt to replace NONMEM directly; position as "the platform that makes NONMEM results accessible to the whole team"; babelmixr2-style translation layer |
| **Small initial user base** | Medium | Academic free tier for community building; partnership with training programs (PAGE, ACoP workshops); open-source model library contributions |
| **Competitor response** | Medium | PumasAI is the most likely reactive competitor; Datagrok's advantage is platform integration (data + viz + compute), not raw estimation speed |

---

## 5. Success Criteria

### Phase 1 MVP (Month 4)

| Metric | Target |
|--------|--------|
| MAP estimation accuracy | Individual parameter estimates within 5% of NONMEM POSTHOC on 3 benchmark datasets |
| Estimation speed | < 2 seconds for 1-compartment analytical model, 100 subjects |
| Data parser coverage | Correctly parse 90%+ of NMTRAN datasets from public repositories (e.g., DDMoRe) |
| User validation | 3 external pharmacometricians complete a full MAP estimation workflow without support |

### Phase 2 (Month 8)

| Metric | Target |
|--------|--------|
| SAEM population estimates | Population bias < 10% vs. NONMEM on theophylline and warfarin benchmark datasets |
| Diagnostic completeness | Auto-generated GOF, CWRES, shrinkage for every completed estimation |
| Clinical pharmacologist adoption | 2 clinical pharmacologists independently run a PopPK analysis using the GUI workflow |

### Phase 3 (Month 12)

| Metric | Target |
|--------|--------|
| FOCE-I OFV match | Within 0.1% of NONMEM OFV on 5 benchmark models |
| VPC generation | < 30 seconds for 500 simulation replicates, 200 subjects |
| NONMEM interoperability | Successfully import 80%+ of standard NONMEM control streams |
| Pilot customer | 1 pharma/biotech company using PopPK Studio for a real analysis |

### Phase 4 (Month 18)

| Metric | Target |
|--------|--------|
| Regulatory submission | At least 1 regulatory submission (IND/NDA) includes PopPK Studio-generated analysis |
| Active users | 50+ monthly active users across pharma, biotech, and academia |
| Platform revenue impact | Measurable contribution to Datagrok pharma license renewals |
| Analyst time savings | 40%+ reduction in time from data to regulatory-ready report vs. NONMEM+R workflow |

---

## Summary

PopPK Studio fills a clear market gap — browser-native population PK/PD modeling — in a $600M+ market growing at 10%+ annually. It builds on Datagrok's existing ODE solver, fitting infrastructure, and visualization capabilities, requiring ~50–68 person-months to reach full platform maturity. The MVP (4 months) delivers immediate value for precision dosing, while Phase 2–3 achieve competitive parity with NONMEM and Monolix. The strategic moat is not replicating a Fortran engine — it is wrapping equivalent statistical rigor in a modern, collaborative, browser-native experience that makes pharmacometric analysis accessible to the entire drug development team.
