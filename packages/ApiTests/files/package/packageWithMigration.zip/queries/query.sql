--name: AccessTableA
--connection: apitest_db
select id from apitest_db.a where value = 1;
--end
