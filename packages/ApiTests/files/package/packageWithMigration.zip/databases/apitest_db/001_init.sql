create table apitest_db.a (
    id int primary key,
    value int 
);

GRANT ALL ON TABLE apitest_db.a to :LOGIN;

insert into apitest_db.a (id, value) values 
(1, 1),
(2, 2);