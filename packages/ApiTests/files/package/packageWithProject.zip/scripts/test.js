//name: test
//input: string a
//output: string b
//tags: model
//language: javascript

b = a
