create table apitest_db.b (
    id int primary key,
    value int 
);

GRANT ALL ON TABLE apitest_db.b to :LOGIN;

insert into apitest_db.b (id, value) values 
(1, 1),
(2, 2);