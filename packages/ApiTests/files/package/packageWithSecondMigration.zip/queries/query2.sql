--name: AccessTableB
--connection: apitest_db
select id from apitest_db.b where value = 1;
--end
